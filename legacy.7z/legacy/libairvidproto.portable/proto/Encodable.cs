﻿
namespace libairvidproto.types
{
    public interface Encodable
    {
        void Encode(Encoder encoder);
    }
}
