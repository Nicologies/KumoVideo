﻿
namespace libairvidproto.model
{
    public class AudioStream : StreamBase
    {
    }
}
