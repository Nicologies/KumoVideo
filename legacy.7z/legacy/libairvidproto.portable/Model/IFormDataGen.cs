namespace libairvidproto.model
{
    public interface IFormDataGen
    {
        byte[] GetFormData();
    }
}