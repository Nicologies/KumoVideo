﻿
namespace libairvidproto.model
{
    public class VideoStream : StreamBase
    {
        public int Width = 0;
        public int Height = 0;

        public VideoStream()
        {
        }
    }
}
